/* -*- mode: C++; c-basic-offset: 2; indent-tabs-mode: nil -*- */
/*
 *  Main authors:
 *     Filip Konvicka <filip.konvicka@logis.cz>
 *
 *  Copyright:
 *     LOGIS, s.r.o., 2008
 *
 *  Last modified:
 *     $Date$ by $Author$
 *     $Revision$
 *
 *  Permission is hereby granted, free of charge, to any person obtaining
 *  a copy of this software and associated documentation files (the
 *  "Software"), to deal in the Software without restriction, including
 *  without limitation the rights to use, copy, modify, merge, publish,
 *  distribute, sublicense, and/or sell copies of the Software, and to
 *  permit persons to whom the Software is furnished to do so, subject to
 *  the following conditions:
 *
 *  The above copyright notice and this permission notice shall be
 *  included in all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 *  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 *  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 *  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */

#pragma warning(disable : 4251 4355)

#include <gecode/kernel.hh>
#include <gecode/search.hh>

#include <float/float.hh>

using namespace Gecode::Float;
using Gecode::ViewArray;

typedef double numeric_type;
typedef boost::numeric::interval<numeric_type> interval_type;
// Instantiate some templates to enable using numeric_type with FloatVar
GECODE_FLOAT_BI_INSTANTIATE(numeric_type);
#include <float/float/bi/prop.icc>

// Basic typedefs
typedef FloatVar<interval_type>             DFloatVar;
typedef FloatView<interval_type>            DFloatView;
typedef ViewArray<DFloatView>               DFloatViewArray;
typedef FloatVarArray<DFloatVar>            DFloatVarArray;
typedef Gecode::PrimArgArray<interval_type> DFloatArgArray;


struct TestSpace : public Gecode::Space {
  DFloatVar       v1;
  DFloatVar       v2;
  DFloatVarArray  vars;
  DFloatVarArray  vars600;
  Gecode::BoolVar bv;
  const int test_number;
  TestSpace(int test_number)
    : test_number(test_number)
    , v1     (this, interval_type(0., 100.))
    , v2     (this, interval_type(0., 100.))
    , vars   (this, 3, interval_type(0., 100.))
    , vars600(this, 600, interval_type(0., 100.))
    , bv     (this, 0, 1)
  {
    switch(test_number) {
    case 0: {
      GECODE_ME_FAIL(this, v1.gq(this, 50.));
      GECODE_ES_FAIL(this, Relational_post(this, v1, FLOAT_REL_LQ, v2));
    } break;
    case 1: {
      GECODE_ME_FAIL(this, v1.lq(this, 50.));
      GECODE_ES_FAIL(this, ReifiedRelational_post(this, v1, FLOAT_REL_LQ, v2, bv));
      GECODE_ME_FAIL(this, v2.gq(this, 50.));
    } break;
    case 2: {
      GECODE_ME_FAIL(this, v1.gq(this, 50.));
      GECODE_ES_FAIL(this, ReifiedRelational_post(this, v1, FLOAT_REL_LQ, v2, bv));
      GECODE_ME_FAIL(this, v2.lq(this, 49.));
    } break;
    case 3: {
      GECODE_ME_FAIL(this, v1.gq(this, 50.));
      GECODE_ES_FAIL(this, ReifiedRelational_post(this, v1, FLOAT_REL_LQ, v2, bv));
      GECODE_ME_FAIL(this, Gecode::Int::BoolView(bv).eq(this, 1));
    } break;
    case 4: {
      GECODE_ES_FAIL(this, Linear_post(this, vars, FLOAT_REL_LQ, 5));
    } break;
    case 5: {
      GECODE_ES_FAIL(this, ReifiedLinear_post(this, vars, FLOAT_REL_LQ, 300, bv));
    } break;
    case 6: {
      GECODE_ES_FAIL(this, ReifiedLinear_post(this, vars, FLOAT_REL_GQ, 400, bv));
    } break;
    case 7: {
      GECODE_ES_FAIL(this, ReifiedLinear_post(this, vars, FLOAT_REL_LQ, 5, bv));
      GECODE_ME_FAIL(this, Gecode::Int::BoolView(bv).eq(this, 1));
    } break;
    case 8: {
      GECODE_ES_FAIL(this, ReifiedLinear_post(this, vars, FLOAT_REL_LQ, 5, bv));
      GECODE_ME_FAIL(this, Gecode::Int::BoolView(bv).eq(this, 1));
      GECODE_ME_FAIL(this, vars[0].eq(this, 4));
    } break;
    case 9: {
      GECODE_ES_FAIL(this, Linear_post(this, vars, FLOAT_REL_LQ, 5));
      GECODE_ME_FAIL(this, vars[2].lq(this, 4));
      Split_domains_with_threshold<SelectVar::MaxBound, true>(this, vars, 3, 0.001);
    } break;
    case 10: {
      GECODE_ES_FAIL(this, Linear_post(this, vars, FLOAT_REL_LQ, 5));
      GECODE_ME_FAIL(this, vars[2].lq(this, 4));
      Split_domains<SelectVar::MaxWidth, true>(this, vars, 0.001);
    } break;
    case 20: {
      const int s=601;
      DFloatArgArray  coeff(s);
      DFloatViewArray a(this, s);
      for(int i=0; i<s-1; i++) {
        coeff[i] = 1.;
        a[i] = vars600[i];
      }
      coeff[s-1] = -1.;
      a[s-1] = v1;
      GECODE_ES_FAIL(this, Linear_post(this, coeff, a, FLOAT_REL_GQ, 0));
    } break;
    }
  }

  TestSpace(bool share, TestSpace& e)
    : Space(share, e)
    , test_number(e.test_number)
    , v1(e.v1)
    , v2(e.v2)
    , vars(e.vars)
    , vars600(e.vars600)
    , bv(e.bv)
	{
		v1.update(this, share, e.v1);
		v2.update(this, share, e.v2);
		vars.update(this, share, e.vars);
    bv.update(this, share, e.bv);
	}

  virtual Space* copy(bool share) {
		return new TestSpace(share, *this);
	}
	virtual ~TestSpace() {}
};

#include <iostream>
using namespace std;

// Enable printing of interval_type
namespace boost { namespace numeric {
  ostream& operator<<(ostream& os, interval_type const& i) {
    os << "[" << i.lower() << "; " << i.upper() << "]";
    return os;
  }
} }

#define CHECK(x) \
  { cout << t.test_number << ". " << ((x) ? "PASS" : "FAIL" ) << ":  " << #x << endl; }

int main(int, char*[]) {
  {
    TestSpace t(0);
    CHECK(t.status() == Gecode::SS_SOLVED);
    using namespace boost::numeric::interval_lib::compare::lexicographic;
    CHECK(t.v1.domain() == interval_type(50., 100.));
    CHECK(t.v2.domain() == interval_type(50., 100.));
  }
  {
    TestSpace t(1);
    CHECK(t.status() == Gecode::SS_SOLVED);
    using namespace boost::numeric::interval_lib::compare::lexicographic;
    CHECK(t.v1.domain() == interval_type(0., 50.));
    CHECK(t.v2.domain() == interval_type(50., 100.));
    CHECK(t.bv.val() == 1);
  }
  {
    TestSpace t(2);
    CHECK(t.status() == Gecode::SS_SOLVED);
    using namespace boost::numeric::interval_lib::compare::lexicographic;
    CHECK(t.v1.domain() == interval_type(50., 100.));
    CHECK(t.v2.domain() == interval_type(0.,  49.));
    CHECK(t.bv.val() == 0);
  }
  {
    TestSpace t(3);
    CHECK(t.status() == Gecode::SS_SOLVED);
    using namespace boost::numeric::interval_lib::compare::lexicographic;
    CHECK(t.v1.domain() == interval_type(50., 100.));
    CHECK(t.v2.domain() == interval_type(50., 100.));
  }
  {
    TestSpace t(4);
    CHECK(t.status() == Gecode::SS_SOLVED);
    using namespace boost::numeric::interval_lib::compare::lexicographic;
    CHECK(t.vars[0].domain() == interval_type(0., 5.));
    CHECK(t.vars[1].domain() == interval_type(0., 5.));
    CHECK(t.vars[2].domain() == interval_type(0., 5.));
  }
  {
    TestSpace t(5);
    CHECK(t.status() == Gecode::SS_SOLVED);
    CHECK(t.bv.val() == 1);
  }
  {
    TestSpace t(6);
    CHECK(t.status() == Gecode::SS_SOLVED);
    CHECK(t.bv.val() == 0);
  }
  {
    TestSpace t(7);
    CHECK(t.status() == Gecode::SS_SOLVED);
    using namespace boost::numeric::interval_lib::compare::lexicographic;
    CHECK(t.vars[0].domain() == interval_type(0., 5.));
    CHECK(t.vars[1].domain() == interval_type(0., 5.));
    CHECK(t.vars[2].domain() == interval_type(0., 5.));
  }
  {
    TestSpace t(8);
    CHECK(t.status() == Gecode::SS_SOLVED);
    using namespace boost::numeric::interval_lib::compare::lexicographic;
    CHECK(t.vars[0].domain() == 4.);
    CHECK(t.vars[1].domain() == interval_type(0., 1.));
    CHECK(t.vars[2].domain() == interval_type(0., 1.));
  }
  {
    Gecode::Search::Options opt;
    opt.c_d=1;
    opt.a_d=0;
    TestSpace t(9);
    CHECK(t.status() == Gecode::SS_BRANCH);
    Gecode::DFS<TestSpace> s(&t, opt);
    int sols=0;
    TestSpace *ts;
    do {
      ts=s.next();
      if ( !ts )
        break;
      sols++;
      /*
      cout << "Solution:" << endl;
      cout << ts->vars[0].domain() << endl;
      cout << ts->vars[1].domain() << endl;
      cout << ts->vars[2].domain() << endl;
      */
    } while(true);
    CHECK(sols == 12);
  }
  {
    TestSpace t(10);
    CHECK(t.status() == Gecode::SS_BRANCH);
  }
  {
    TestSpace t(20);
    Gecode::SpaceStatus ss = t.status();
    CHECK(t.status() == Gecode::SS_SOLVED);
  }
  return 0;
}

