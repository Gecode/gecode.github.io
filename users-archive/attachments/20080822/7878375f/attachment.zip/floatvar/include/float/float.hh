/* -*- mode: C++; c-basic-offset: 2; indent-tabs-mode: nil -*- */
/*
 *  Main authors:
 *     Filip Konvicka <filip.konvicka@logis.cz>
 *
 *  Copyright:
 *     LOGIS, s.r.o., 2008
 *
 *  Last modified:
 *     $Date$ by $Author$
 *     $Revision$
 *
 *  Permission is hereby granted, free of charge, to any person obtaining
 *  a copy of this software and associated documentation files (the
 *  "Software"), to deal in the Software without restriction, including
 *  without limitation the rights to use, copy, modify, merge, publish,
 *  distribute, sublicense, and/or sell copies of the Software, and to
 *  permit persons to whom the Software is furnished to do so, subject to
 *  the following conditions:
 *
 *  The above copyright notice and this permission notice shall be
 *  included in all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 *  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 *  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 *  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */

#if !defined(GECODE__FLOAT_HH)
#define GECODE__FLOAT_HH

#include <gecode/kernel.hh>
#include <gecode/int.hh>

#include <boost/static_assert.hpp>

namespace Gecode { namespace Float {

#pragma region // Forward declarations
  // Generic:
template<typename DomainType> class  FloatVar;
template<typename DomainType> class  FloatView;
template<typename FloatVarI>  struct FloatVarArray;
template<typename FV, typename Fct, typename ValFct> class Split;
  // Specialized:
template<typename DomainType> struct FloatVarImp;
template<typename DomainType> class  FloatDelta;
template<typename DomainType> class  ScaleView;
template<typename DomainType> struct FloatPropagatorBase;
template<typename DomainType, typename FV1, typename FV2> class  Relational;
template<typename DomainType, typename FV1, typename FV2, typename BV> class  ReifiedRelational;
template<typename DomainType, typename FV1, typename FV2, typename FV3> class  Arithmetic;
template<typename DomainType, typename FV> class  Linear;
template<typename DomainType, typename FV, typename BV> class  ReifiedLinear;
#pragma endregion

#pragma region // Helper templates for passing variables/views
namespace __Utils {
// Converts FloatVar to FloatView, or retains original float view type.
template<typename ViewType> struct FloatVarToView {
  typedef ViewType        type;
  typedef ViewType const& arg_type;
};

template<typename T> struct FloatVarToView<FloatVar<T> > {
  typedef FloatView<T>  type;
  typedef type          arg_type;
};

// Converts VarArray<FloatVar> to ViewArray<FloatView>, or retains original var array type.
template<typename ViewArrayType> struct FloatVarsToViews;

template<typename ViewType> struct FloatVarsToViews<ViewArray<ViewType> > {
  typedef typename ViewType::interval_type  interval_type;
  typedef ViewType                          view_type;
  typedef ViewArray<ViewType> const&        init_type;
  typedef ViewArray<ViewType>               type;
};

template<typename T> struct FloatVarsToViews<VarArgArray<FloatVar<T> > > {
  typedef T                                 interval_type;
  typedef FloatView<T>                      view_type;
  typedef VarArgArray<FloatVar<T> > const&  init_type;
  typedef ViewArray<view_type>              type;
};

template<typename T> struct FloatVarsToViews<VarArray<FloatVar<T> > > {
  typedef T                         interval_type;
  typedef FloatView<T>              view_type;
  typedef VarArgArray<FloatVar<T> > init_type;
  typedef ViewArray<view_type>      type;
};

template<typename T> struct FloatVarsToViews<FloatVarArray<FloatVar<T> > > {
  typedef T                         interval_type;
  typedef FloatView<T>              view_type;
  typedef VarArgArray<FloatVar<T> > init_type;
  typedef ViewArray<view_type>      type;
};

// Converts BoolVar to BoolView, and retains original view type otherwise.
template<typename ViewType> struct BoolVarToView {
  typedef ViewType        type;
  typedef ViewType const& arg_type;
};

template<> struct BoolVarToView<Gecode::BoolVar> {
  typedef Gecode::Int::BoolView type;
  typedef type                  arg_type;
};
} // namespace __Utils
#pragma endregion

} // namespace Float

} // namespace Gecode

#pragma region // Generic templates definitions/declarations
// Variable (definition), variable implementation & delta (empty generic declaration)
#include "float/float_var.hh"
// FloatView (definition), ScaleView (empty generic declaration)
#include "float/float_view.hh"
// Operator definitions, propagators (relational, arithmetic, linear...) - empty generic declarations
#include "float/float_prop.hh"
// Branchings
#include "float/float_branching.hh"
#pragma endregion

// Boost.Interval implementation
#include "float/bi/delta.icc"
#include "float/bi/varimp.icc"
#include "float/bi/view.icc"
#include "float/bi/prop.hh"

/// Instantiates all FloatVar<Boost.Interval> classes for the given numeric type.
#define GECODE_FLOAT_BI_INSTANTIATE(NumericType)                              \
  namespace Gecode {                                                          \
  GECODE_FLOAT_REGISTER_IMPL(boost::numeric::interval<NumericType>);          \
  namespace Float {                                                           \
  template class FloatVar<boost::numeric::interval<NumericType> >;            \
  template class FloatView<boost::numeric::interval<NumericType> >;           \
  template class FloatDelta<boost::numeric::interval<NumericType> >;          \
  template struct FloatVarImp<boost::numeric::interval<NumericType> >;        \
  template class ScaleView<boost::numeric::interval<NumericType> >;           \
  } }

#endif // !GECODE__FLOAT_HH

