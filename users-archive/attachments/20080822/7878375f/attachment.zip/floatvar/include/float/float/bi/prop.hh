/* -*- mode: C++; c-basic-offset: 2; indent-tabs-mode: nil -*- */
/*
 *  Main authors:
 *     Filip Konvicka <filip.konvicka@logis.cz>
 *     Lubomir Moric <lubomir.moric@logis.cz>
 *
 *  Copyright:
 *     LOGIS, s.r.o., 2008
 *
 *  Last modified:
 *     $Date$ by $Author$
 *     $Revision$
 *
 *  Permission is hereby granted, free of charge, to any person obtaining
 *  a copy of this software and associated documentation files (the
 *  "Software"), to deal in the Software without restriction, including
 *  without limitation the rights to use, copy, modify, merge, publish,
 *  distribute, sublicense, and/or sell copies of the Software, and to
 *  permit persons to whom the Software is furnished to do so, subject to
 *  the following conditions:
 *
 *  The above copyright notice and this permission notice shall be
 *  included in all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 *  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 *  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 *  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef FLOAT_BI__FLOAT_PROP_HH
#define FLOAT_BI__FLOAT_PROP_HH

#include <boost/numeric/interval.hpp>

namespace Gecode { namespace Float {

#define __BI_T              boost::numeric::interval<T>

/// FloatPropagatorBase specialization for Boost.Interval.
template<typename T>
struct FloatPropagatorBase<boost::numeric::interval<T> > {
public:
  /// Interval type;
  typedef __BI_T interval_type;
  /// View type.
  typedef Gecode::Float::FloatView<interval_type>     ViewType;
  /// Var type.
  typedef Gecode::Float::FloatVar<interval_type>      FloatVarType;
};

/// Relational propagator implementation (specialization for Boost.Interval).
template<typename T, typename FV1, typename FV2>
class Relational<__BI_T, FV1, FV2> : public FloatPropagatorBase<__BI_T>, public Propagator
{
  /// Reference to the 1st operand.
  FV1 op1;
  /// Reference to the 2nd operand.
  FV2 op2;
  /// The arithmetic relation
  Float_Rel rl;

  /// Construction. Use #post to post an instance of this propagator.
  Relational(Space* home, FV1 const& _op1, Float_Rel _rl, FV2 const& _op2);
  /// Utility constructor
  Relational(Space* home, bool share, Relational& p);

public:
  virtual size_t dispose(Space* home);
  
  virtual Actor* copy(Space* home, bool share);
  
  virtual Gecode::PropCost cost(Gecode::ModEventDelta) const;
  
  static ExecStatus post(Space* home, FV1 const& op1, Float_Rel rl, FV2 const& op2);

  ExecStatus propagate(Space* home, ModEventDelta);
};

/// Helper for posting #Relational constraints.
template<typename F1, typename F2>
inline ExecStatus Relational_post(Space* home, F1 const& v1, Float_Rel rl, F2 const& v2)
{
  using namespace __Utils;
  typename FloatVarToView<F1>::arg_type vw1=v1;
  typename FloatVarToView<F2>::arg_type vw2=v2;
  BOOST_STATIC_ASSERT((
    boost::is_same<
      typename F1::interval_type,
      typename F2::interval_type>::value));
  return Relational<
    typename F1::interval_type,
    typename FloatVarToView<F1>::type,
    typename FloatVarToView<F2>::type>
    ::post(home, vw1, rl, vw2);
}

/// Reified arithmetic binary relation propagator implementation for Boost.Interval.
template<typename T, typename FV1, typename FV2, typename BV>
class ReifiedRelational<__BI_T, FV1, FV2, BV> : public FloatPropagatorBase<__BI_T>, public Propagator
{
  FV1       op1;  ///< First operand
  FV2       op2;  ///< Second operand
  Float_Rel rl;   ///< The binary relation
  BV        bv;   ///< The reflection Boolean

  /// Construction
  ReifiedRelational(Space* home, FV1 const& _op1, Float_Rel _rl, FV2 const& _op2, BV const& _bv);
  /// Utility constructor.
  ReifiedRelational(Space* home, bool share, ReifiedRelational& p);
  
public:
  virtual size_t dispose(Space* home);

  virtual Actor* copy(Space* home, bool share);
  
  virtual Gecode::PropCost cost(Gecode::ModEventDelta) const;
  
  static ExecStatus post(Space* home, FV1 const& op1, Float_Rel rl, FV2 const& op2, BV const& bv);
  
  ExecStatus propagate(Space* home, ModEventDelta);
};

/// Helper for posting #ReifiedRelational constraints.
template<typename F1, typename F2, typename BV>
inline ExecStatus ReifiedRelational_post(Space* home, F1 const& v1, Float_Rel rl, F2 const& v2, BV const& bv)
{
  using namespace __Utils;
  typename FloatVarToView<F1>::arg_type vw1=v1;
  typename FloatVarToView<F2>::arg_type vw2=v2;
  typename BoolVarToView<BV>::arg_type  bvw=bv;
  BOOST_STATIC_ASSERT((
    boost::is_same<
      typename F1::interval_type,
      typename F2::interval_type>::value));
  return ReifiedRelational<
    typename F1::interval_type,
    typename FloatVarToView<F1>::type,
    typename FloatVarToView<F2>::type,
    typename BoolVarToView<BV>::type>
    ::post(home, vw1, rl, vw2, bvw);
}

/// Ternary arithmetic propagator specialization for Boost.Interval.
template<typename T, typename FV1, typename FV2, typename FV3>
class Arithmetic<__BI_T, FV1, FV2, FV3> : public FloatPropagatorBase<__BI_T>, public Propagator
{
  FV1 op1;    ///< The first operand
  FV2 op2;    ///< The second operand
  FV3 res;    ///< The result
  Float_F f;  ///< The operator

  /// Construction  
  Arithmetic(Space* home, FV1 const& _op1, FV2 const& _op2, Float_F _f, FV3 const& _res);
  /// Utility constructor.
  Arithmetic(Space* home, bool share, Arithmetic& p);
  
public:
  virtual size_t dispose(Space* home);
  
  virtual Actor* copy(Space* home, bool share);
  
  virtual Gecode::PropCost cost(Gecode::ModEventDelta) const;
  
  static ExecStatus post(Space* home, FV1 const& op1, FV2 const& op2, Float_F f, FV3 const& res);

  ExecStatus propagate(Space* home, ModEventDelta);
};

/// Helper for posting #Arithmetic constraints.
template<typename F1, typename F2, typename F3>
inline ExecStatus Arithmetic_post(Space* home, F1 const& op1, F2 const& op2, Float_F f, F3 const& res)
{
  using namespace __Utils;
  BOOST_STATIC_ASSERT((boost::is_same<typename F1::constant_type, typename F2::constant_type>::value));
  BOOST_STATIC_ASSERT((boost::is_same<typename F2::constant_type, typename F3::constant_type>::value));

  typename FloatVarToView<F1>::arg_type vw1=op1;
  typename FloatVarToView<F2>::arg_type vw2=op2;
  typename FloatVarToView<F3>::arg_type vw3=res;
  BOOST_STATIC_ASSERT((
    boost::is_same<
      typename F1::interval_type,
      typename F2::interval_type>::value));
  return Arithmetic<
    typename F1::interval_type,
    typename FloatVarToView<F1>::type,
    typename FloatVarToView<F2>::type,
    typename FloatVarToView<F3>::type
    >
    ::post(home, vw1, vw2, f, vw3);
}

/// Linear arithmetic propagator specialization for Boost.Interval.
template<typename T, typename FV>
class Linear<__BI_T, FV> : public FloatPropagatorBase<__BI_T>, public Propagator
{
  // Helper typedefs
  typedef typename FV::numeric_type      numeric_type;
  typedef typename FV::constant_type     constant_type;
  typedef typename FV::constant_type_cr  constant_type_arg;

  /// The operands.
  ViewArray<FV> operands;
  /// The operator
  Float_Rel rel;
  /// The right-hand side.
  constant_type rhs;

  /// Construction  
  Linear(Space* home, ViewArray<FV> const& operands, Float_Rel rel, constant_type_arg rhs);
  /// Utility constructor.
  Linear(Space* home, bool share, Linear& p);

  /// Simplifies the constraint (posts a new instance of this constraint) and returns @c true; returns @c false if no simplification is possible.
  inline static ExecStatus simplify(Space* home, ViewArray<FV> const& operands, Float_Rel rel, constant_type_arg rhs, Propagator *p=0);
  /// Real 'post'
  inline static ExecStatus _post(Space* home, ViewArray<FV> const& operands, Float_Rel rel, constant_type_arg rhs);
public:
  virtual size_t dispose(Space* home);

  virtual Actor* copy(Space* home, bool share);

  virtual Gecode::PropCost cost(Gecode::ModEventDelta) const;

  static ExecStatus post(Space* home, ViewArray<FV> const& operands, Float_Rel rel, constant_type rhs);

  ExecStatus propagate(Space* home, ModEventDelta);
};

/// Helper for posting #Linear constraints.
template<typename T, typename FVA>
inline ExecStatus Linear_post(Space* home,
                         FVA const& operands,
                         Float_Rel rel,
                         T const& rhs)
{
  using namespace __Utils;
  typename FloatVarsToViews<FVA>::type opvw(home,
    static_cast<typename FloatVarsToViews<FVA>::init_type>(operands));
  return Linear<
    typename FloatVarsToViews<FVA>::interval_type,
    typename FloatVarsToViews<FVA>::view_type>::
    post(home, opvw, rel, rhs);
}

/// Helper for posting #Linear constraints.
template<typename T, typename FVA, typename T2>
inline ExecStatus Linear_post(Space* home,
                         PrimArgArray<boost::numeric::interval<T> > const& coefficients,
                         FVA const& operands,
                         Float_Rel rel,
                         T2 const& rhs)
{
  using namespace __Utils;
  typename FloatVarsToViews<FVA>::type opvw(home,
    static_cast<typename FloatVarsToViews<FVA>::init_type>(operands));

  BOOST_STATIC_ASSERT((boost::is_same<
    typename FloatVarsToViews<FVA>::interval_type,
    boost::numeric::interval<T> >::value));

  assert(coefficients.size()==operands.size()); // TODO - exception

  size_t count=0, ii=0;
  for(int i=0; i<operands.size(); ++i) {
    if ( !boost::numeric::interval_lib::user::is_zero(coefficients[i]) )
      count++;
  }
  ViewArray<Gecode::Float::ScaleView<__BI_T> > new_operands(home, count);
  for(int i=0; i<operands.size(); ++i) {
    if ( boost::numeric::interval_lib::user::is_zero(coefficients[i]) )
      continue;
    new_operands[ii++].init(coefficients[i], opvw[i]);
  }

  return Linear<
    typename FloatVarsToViews<FVA>::interval_type,
    typename Gecode::Float::ScaleView<__BI_T> >::
    post(home, new_operands, rel, rhs);
}

/// Linear arithmetic propagator specialization for Boost.Interval.
template<typename T, typename FV, typename BV>
class ReifiedLinear<__BI_T, FV, BV> : public FloatPropagatorBase<__BI_T>, public Propagator
{
  // Helper typedefs
  typedef typename FV::numeric_type      numeric_type;
  typedef typename FV::constant_type     constant_type;
  typedef typename FV::constant_type_cr  constant_type_arg;

  /// The operands.
  ViewArray<FV> operands;
  /// The operator
  Float_Rel rel;
  /// The right-hand side.
  constant_type rhs;
  
  /// The reflection Boolean
  BV  bv;
  
  /// Construction  
  ReifiedLinear(Space* home,
        ViewArray<FV> const& operands,
        Float_Rel rel,
        constant_type_arg rhs,
        BV const& _bv);
  /// Utility constructor.
  ReifiedLinear(Space* home, bool share, ReifiedLinear& p);

  /// Simplifies the constraint (posts a new instance of this constraint) and returns @c true; returns @c false if no simplification is possible.
  inline static ExecStatus simplify(Space* home, ViewArray<FV> const& operands, Float_Rel rel, constant_type_arg rhs, BV const& bv, Propagator *p=0);
  /// Real 'post'
  inline static ExecStatus _post(Space* home, ViewArray<FV> const& operands, Float_Rel rel, constant_type_arg rhs, BV const& bv);
public:
  virtual size_t dispose(Space* home);

  virtual Actor* copy(Space* home, bool share);

  virtual Gecode::PropCost cost(Gecode::ModEventDelta) const;

  /// Sum of all operands (unit coefficients)
  static ExecStatus post(Space* home,
                         ViewArray<FV> const& operands,
                         Float_Rel rel,
                         constant_type rhs,
                         BV const& bv);

  ExecStatus propagate(Space* home, ModEventDelta);
};

/// Helper for posting #Linear constraints.
template<typename T, typename FVA, typename BV>
inline ExecStatus ReifiedLinear_post(Space* home,
                         FVA const& operands,
                         Float_Rel rel,
                         T const& rhs,
                         BV const& bv)
{
  using namespace __Utils;
  typename FloatVarsToViews<FVA>::type opvw(home,
    static_cast<typename FloatVarsToViews<FVA>::init_type>(operands));
  typename BoolVarToView<BV>::arg_type  bvw=bv;
  return ReifiedLinear<
    typename FloatVarsToViews<FVA>::interval_type,
    typename FloatVarsToViews<FVA>::view_type,
    typename BoolVarToView<BV>::type>::
    post(home, opvw, rel, rhs, bv);
}

/// Helper for posting #ReifiedLinear constraints.
template<typename T, typename FVA, typename T2, typename BV>
inline ExecStatus ReifiedLinear_post(Space* home,
                         PrimArgArray<boost::numeric::interval<T> > const& coefficients,
                         FVA const& operands,
                         Float_Rel rel,
                         T2 const& rhs,
                         BV const& bv)
{
  using namespace __Utils;
  typename FloatVarsToViews<FVA>::type opvw(home,
    static_cast<typename FloatVarsToViews<FVA>::init_type>(operands));
  typename BoolVarToView<BV>::arg_type  bvw=bv;

  BOOST_STATIC_ASSERT((boost::is_same<
    typename FloatVarsToViews<FVA>::interval_type,
    boost::numeric::interval<T> >::value));

  assert(coefficients.size()==operands.size()); // TODO - exception

  size_t count=0, ii=0;
  for(int i=0; i<operands.size(); ++i) {
    if ( !boost::numeric::interval_lib::user::is_zero(coefficients[i]) )
      count++;
  }
  ViewArray<Gecode::Float::ScaleView<__BI_T> > new_operands(home, count);
  for(int i=0; i<operands.size(); ++i) {
    if ( boost::numeric::interval_lib::user::is_zero(coefficients[i]) )
      continue;
    new_operands[ii++].init(coefficients[i], opvw[i]);
  }

  return ReifiedLinear<
    typename FloatVarsToViews<FVA>::interval_type,
    typename FloatVarsToViews<FVA>::view_type,
    typename BoolVarToView<BV>::type>::
    post(home, new_operands, rel, rhs);
}

#undef __BI_T

} // namespace Float

} // namespace Gecode

#endif // !FLOAT_BI__FLOAT_PROP_HH
