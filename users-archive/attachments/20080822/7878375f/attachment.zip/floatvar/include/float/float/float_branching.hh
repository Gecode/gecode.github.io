/* -*- mode: C++; c-basic-offset: 2; indent-tabs-mode: nil -*- */
/*
*  Main authors:
*     Petr Kahanek <petr.kahanek@logis.cz>
*     Filip Konvicka <filip.konvicka@logis.cz>
*
*  Copyright:
*     LOGIS, s.r.o., 2008
*
*  Last modified:
*     $Date$ by $Author$
*     $Revision$
*
*  Permission is hereby granted, free of charge, to any person obtaining
*  a copy of this software and associated documentation files (the
*  "Software"), to deal in the Software without restriction, including
*  without limitation the rights to use, copy, modify, merge, publish,
*  distribute, sublicense, and/or sell copies of the Software, and to
*  permit persons to whom the Software is furnished to do so, subject to
*  the following conditions:
*
*  The above copyright notice and this permission notice shall be
*  included in all copies or substantial portions of the Software.
*
*  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
*  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
*  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
*  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
*  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
*  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
*  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*
*/

#if !defined(GECODE_FLOAT_BRANCHING_HH)
#define      GECODE_FLOAT_BRANCHING_HH

#include <vector>
#include <gecode/kernel.hh>
#include "float_var.hh"
#include "float_view.hh"

namespace Gecode { namespace Float {

namespace SelectVar {
  /// Selects a variable with the smallest domain.
  template<typename FV> struct MinWidth {
    typedef typename FV::numeric_type  numeric_type;

    numeric_type  min_width;  ///< Minimum width seen.
    int&          best_index; ///< Best index reference.
    numeric_type  width_threshold;

    /// Construction.
    MinWidth(int& best_index, numeric_type width_threshold)
      : best_index(best_index)
      , width_threshold(width_threshold)
    {
      best_index=-1;
    }
    /// Processes one view.
    inline bool process(FV const& v, int index) {
      if ( v.assigned() || v.width()<width_threshold )
        return true;
      if ( best_index<0 ) {
        min_width=v.width();
        best_index=index;
      }
      else {
        numeric_type this_width=v.width();
        if ( min_width>this_width ) {
          min_width=this_width;
          best_index=index;
        }
      }
      return true;
    }
  };

  /// Selects a variable with the largest domain.
  template<typename FV> struct MaxWidth {
    typedef typename FV::numeric_type  numeric_type;

    numeric_type  max_width;  ///< Maximum width seen.
    int&          best_index; ///< Best index reference.
    numeric_type  width_threshold;

    /// Construction.
    MaxWidth(int& best_index, numeric_type width_threshold)
      : best_index(best_index)
      , width_threshold(width_threshold)
    {
      best_index=-1;
    }
    /// Processes one view.
    inline bool process(FV const& v, int index) {
      if ( v.assigned() || v.width()<width_threshold )
        return true;
      if ( best_index<0 ) {
        max_width=v.width();
        best_index=index;
      }
      else {
        numeric_type this_width=v.width();
        if ( max_width<this_width ) {
          max_width=this_width;
          best_index=index;
        }
      }
      return true;
    }
  };

  /// Selects a variable with the smallest value in its domain.
  template<typename FV> struct MinBound {
    typedef typename FV::numeric_type  numeric_type;

    numeric_type  min_bound;  ///< Minimum bound seen.
    int&          best_index; ///< Best index reference.
    numeric_type  width_threshold;

    /// Construction
    MinBound(int& best_index, numeric_type width_threshold)
      : best_index(best_index)
      , width_threshold(width_threshold)
    {
      best_index=-1;
    }
    /// Processes one view.
    inline bool process(FV const& v, int index) {
      if ( v.assigned() || v.width()<width_threshold )
        return true;
      if ( best_index<0 ) {
        min_bound=v.min();
        best_index=index;
      }
      else {
        numeric_type this_bound=v.min();
        if ( min_bound>this_bound ) {
          min_bound=this_bound;
          best_index=index;
        }
      }
      return true;
    }
  };

  /// Selects a variable with the largest value in its domain.
  template<typename FV> struct MaxBound {
    typedef typename FV::numeric_type  numeric_type;

    numeric_type  max_bound;  ///< Maximum bound seen.
    int&          best_index; ///< Best index reference.
    numeric_type  width_threshold;

    /// Construction.
    MaxBound(int& best_index, numeric_type width_threshold)
      : best_index(best_index)
      , width_threshold(width_threshold)
    {
      best_index=-1;
    }
    /// Processes one view.
    inline bool process(FV const& v, int index) {
      if ( v.assigned() || v.width()<width_threshold )
        return true;
      if ( best_index<0 ) {
        max_bound=v.max();
        best_index=index;
      }
      else {
        numeric_type this_bound=v.max();
        if ( max_bound<this_bound ) {
          max_bound=this_bound;
          best_index=index;
        }
      }
      return true;
    }
  };

  /// Selects any variable.
  template<typename FV> struct Naive {
    typedef typename FV::numeric_type  numeric_type;
    int&  best_index; ///< Best variable index reference.
    numeric_type  width_threshold;

    /// Construction.
    Naive(int& best_index, numeric_type width_threshold)
      : best_index(best_index)
      , width_threshold(width_threshold)
    {
      best_index=-1;
    }
    /// Processes one view.
    inline bool process(FV const& v, int index) {
      if ( v.assigned() || v.width()<width_threshold )
        return true;
      best_index=index;
      return false;
    }
  };
}

namespace SelectVal {
  /// Selects lower / upper half of the domain; when the domain width is smaller than the specified threshold,
  /// immediately selects the lower / upper bound as the value. Note that this skips a lot of solutions.
  template<typename FV, bool upperFirst> struct HalfWithThreshold {
    typedef typename FV::numeric_type  numeric_type;
    typedef typename FV::interval_type interval_type;

    numeric_type              threshold;      ///< Domain width threshold.
    std::vector<bool>         tabuInitialized;///< Tells which items in #tabuSecond are initialized.
    /// For each variable, tabu values for second value choice.
    /// This prevents some symmetric solutions.
    std::vector<numeric_type> tabuSecond;
    /// Construction with threshold.
    /// Objects created using this constructor are used just for passing of the threshold value.
    HalfWithThreshold(numeric_type const& t) : threshold(t) {}
    /// Construction.
    HalfWithThreshold(HalfWithThreshold const& src, int size)
      : threshold(src.threshold)
      , tabuInitialized(size)
      , tabuSecond(size)
    {
      std::fill(tabuInitialized.begin(), tabuInitialized.end(), false);
    }
    /// Returns \c true when alternative \i a is to select the upper half (resp. upper bound) of the domain.
    inline static bool upper(int a) {
      return (a==0) == upperFirst;
    }
    /// Modifies the domain of the specified variable according to the alternative \i a.
    /// @param v     The variable.
    /// @param alt1  Receives domain modification for alternative 1.
    /// @param alt2  Receives domain modification for alternative 2.
    /// @return The number of valid alternatives.
    int get(FV const& v, int i, interval_type& alt1, interval_type& alt2) const {
      interval_type& lower=upperFirst ? alt2 : alt1;
      interval_type& upper=upperFirst ? alt1 : alt2;

      if ( v.width()<=threshold ) {
        lower=v.min();
        upper=v.max();
        return ( tabuInitialized[i] && alt2==tabuSecond[i] )
          ? 1
          : 2;
      }
      interval_type const&  domain=v.domain();
      numeric_type          med=v.median();
      lower.set(domain.lower(), med);
      upper.set(med, domain.upper());
      return 2;
    }
    /// To be called by the branching after alternative 1 has reduced the domain of the variable.
    void notifyAlt0(int i, interval_type const& domain) {
      tabuInitialized[i] = true;
      tabuSecond[i] = upperFirst ? domain.lower() : domain.upper();
    }
  };

  /// Selects lower / upper half of the domain.
  template<typename FV, bool upperFirst> struct Half {
    typedef typename FV::numeric_type  numeric_type;
    typedef typename FV::interval_type interval_type;

    /// Construction of a dummy object.
    Half() {}
    /// Construction.
    Half(Half const&, int) {}
    /// Returns \c true when alternative \i a is to select the upper half (resp. upper bound) of the domain.
    inline static bool upper(int a) {
      return (a==0) == upperFirst;
    }
    /// Modifies the domain of the specified variable according to the alternative \i a.
    /// @param v     The variable.
    /// @param alt1  Receives domain modification for alternative 1.
    /// @param alt2  Receives domain modification for alternative 2.
    /// @return The number of valid alternatives.
    static int get(FV const& v, int, interval_type& alt1, interval_type& alt2) {
      interval_type&        lower=upperFirst ? alt2 : alt1;
      interval_type&        upper=upperFirst ? alt1 : alt2;
      interval_type const&  domain=v.domain();
      numeric_type          med=v.median();
      lower.set(domain.lower(), med);
      upper.set(med, domain.upper());
      return 2;
    }
    /// To be called by the branching after alternative 1 has reduced the domain of the variable.
    void notifyAlt0(int, interval_type const&) {}
  };
};

/// Splitting branching - see #Split_domains, #Split_domains_with_threshold.
template<typename FV, typename Fct, typename ValFct>
class Split : public Gecode::Branching {
  /// Base class
  typedef Gecode::Branching   Base;
  /// Numeric type.
  typedef typename FV::numeric_type  numeric_type;
  /// Domain type.
  typedef typename FV::interval_type interval_type;
  /// Views of the variables.
  ViewArray<FV> variables;

  /// Width threshold (variables with narrower domains are considered assigned).
  const numeric_type threshold;

  /// Variable selected for splitting.
  mutable int best_var_index;

  /// Object that is used for modifying the domains.
  ValFct valFct;

  /// Construction.
  Split(Space* home, ViewArray<FV> const& variables_, ValFct const& valFct, const numeric_type threshold)
    : Base(home)
    , variables(variables_)
    , valFct(valFct, variables_.size())
    , threshold(threshold)
  { }
  /// Clone constructor.
  Split(Space* home, bool share, Split& b)
    : Base(home, share, b)
    , valFct(b.valFct)
    , threshold(b.threshold)
  {
    variables.update(home, share, b.variables);
    best_var_index = b.best_var_index;
  }
  /// Destructor.
  virtual ~Split(void) {}

public:
  /// Selects a variable for domain modification.
  /// @return \c false if there is no more branching possible (all variables are assigned).
  virtual bool status(const Space* home) const  {
    Fct fct(best_var_index, threshold);
    for (int i=0; i<(int)variables.size(); i++) {
      FV const& v=variables[i];
      if ( !fct.process(v, i) )
        break;
    }
    return best_var_index!=-1;
  }

  /// A structure that holds the information about a branching.
  /// In fact these are all results of #status.
  struct BranchDesc : public BranchingDesc {
    /// Variable index
    int var_index;
    /// Domain reduction for the first alternative.
    const interval_type alt1;
    /// Domain reduction for the second alternative.
    const interval_type alt2;

    /// Initialize for particular branching \a b
    BranchDesc(const Branching* b,
      int var_index,
      interval_type const& alt1,
      interval_type const& alt2,
      int number_of_alternatives)
      : BranchingDesc(b, number_of_alternatives)
      , var_index(var_index)
      , alt1(alt1)
      , alt2(alt2)
    { }
    /// Destructor
    virtual ~BranchDesc(void) {}

    /// Report size occupied by this branching description
    virtual size_t size(void) const { return sizeof(*this); }
  };

  /// Returns BranchingDesc for the framework. Depends on #status() being called immediately before this.
  virtual BranchingDesc* description(const Space* home) const {
    // computed by "status" above; we can rely on that based on Gecode docs.
    FV const& v=variables[best_var_index];
    interval_type alt1, alt2;
    int nalt=valFct.get(v, best_var_index, alt1, alt2);
    return new BranchDesc(this, best_var_index, alt1, alt2, nalt);
  }
  /// Modify the space according to branching d's alternative "a"
  virtual ExecStatus commit(Space* home, const BranchingDesc* d, unsigned int a) {
    const BranchDesc *b=static_cast<const BranchDesc*>(d);
    FV& v = variables[b->var_index];
    GECODE_ASSUME(boost::numeric::subset(a==0 ? b->alt1 : b->alt2, v.domain()));
    GECODE_ME_CHECK(v.eq(home, a==0 ? b->alt1 : b->alt2));
    if ( a==0 )
      valFct.notifyAlt0(b->var_index, v.domain());
    return ES_OK;
  }

  /// Copying.
  virtual Actor* copy(Space *home, bool share) {
    return new (home) Split(home, share, *this);
  }

  /// Posts a new branching instance.
  static void post(Space* home, ViewArray<FV> const& variables, ValFct const& fct, numeric_type threshold) {
    (void) new (home) Split(home, variables, fct, threshold);
  }

  /// Destroys the object.
  virtual size_t dispose(Space* home) {
    (void) valFct.~ValFct();
    (void) Base::dispose(home);
    return sizeof(*this);
  }

  /// Reflection name
  virtual const char* name(void) const {
    return "Split";
  }
};

/// Posts a domain-splitting branching.
/// \i Which can be one of classes defined in Gecode::Float::SelectVar (e.g. MaxBound, MaxWidth).
/// \i upperFirst specifies whether the upper half of the domain should be tried first.
template<template<typename FV> class Which, bool upperFirst, typename FVA, typename TT>
void Split_domains(Space *home, FVA const& varsOrViews, TT assigned_threshold) {
  using namespace __Utils;
  typename FloatVarsToViews<FVA>::type opvw(home,
    static_cast<typename FloatVarsToViews<FVA>::init_type>(varsOrViews));
  typedef SelectVal::Half<typename FloatVarsToViews<FVA>::view_type, upperFirst> ValFct;
  Split<typename FloatVarsToViews<FVA>::view_type,
    Which<typename FloatVarsToViews<FVA>::view_type>,
    ValFct
  >::post(home, opvw, ValFct(), assigned_threshold);
}

/// Posts a domain-splitting branching with threshold.
/// \i Which can be one of classes defined in Gecode::Float::SelectVar (e.g. MaxBound, MaxWidth).
/// \i upperFirst specifies whether the upper half of the domain should be tried first.
/// When the width of a domain falls below the specified threshold,
/// the branching tries the lower and upper bound
/// (throwing away all solutions with values between the current bounds).
template<template<typename FV> class Which, bool upperFirst, typename FVA, typename T, typename TT>
void Split_domains_with_threshold(Space *home, FVA const& varsOrViews, T const& threshold, TT assigned_threshold) {
  using namespace __Utils;
  typename FloatVarsToViews<FVA>::type opvw(home,
    static_cast<typename FloatVarsToViews<FVA>::init_type>(varsOrViews));
  typedef SelectVal::HalfWithThreshold<typename FloatVarsToViews<FVA>::view_type, upperFirst> ValFct;
  Split<typename FloatVarsToViews<FVA>::view_type,
    Which<typename FloatVarsToViews<FVA>::view_type>,
    ValFct
  >::post(home, opvw, ValFct(threshold), assigned_threshold);
}

} // namespace Float

} // namespace Gecode

#endif // !GECODE_FLOAT_BRANCHING_HH


