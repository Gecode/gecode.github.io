/* -*- mode: C++; c-basic-offset: 2; indent-tabs-mode: nil -*- */
/*
 *  Main authors:
 *     Filip Konvicka <filip.konvicka@logis.cz>
 *     Lubomir Moric <lubomir.moric@logis.cz>
 *
 *  Copyright:
 *     LOGIS, s.r.o., 2008
 *
 *  Last modified:
 *     $Date$ by $Author$
 *     $Revision$
 *
 *  Permission is hereby granted, free of charge, to any person obtaining
 *  a copy of this software and associated documentation files (the
 *  "Software"), to deal in the Software without restriction, including
 *  without limitation the rights to use, copy, modify, merge, publish,
 *  distribute, sublicense, and/or sell copies of the Software, and to
 *  permit persons to whom the Software is furnished to do so, subject to
 *  the following conditions:
 *
 *  The above copyright notice and this permission notice shall be
 *  included in all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 *  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 *  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 *  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */

#if !defined(FLOAT__FLOAT_VAR_HH)
#define FLOAT__FLOAT_VAR_HH

namespace Gecode { namespace Float {

/// Floating-point modification delta.
/// The \c DomainType argument is the underlying floating-point interval implementation.
template<typename DomainType>
class FloatDelta {
  // Please specialize this template for DomainType.
#if defined(BOOST_STATIC_ASSERT)
  BOOST_STATIC_ASSERT(sizeof(DomainType)==0);
#endif
};

/// Floating-point interval variable implementation.
/// The \c DomainType argument is the underlying floating-point interval implementation.
template<typename DomainType>
struct FloatVarImp {
  // Please specialize this for DomainType.
#if defined(BOOST_STATIC_ASSERT)
  BOOST_STATIC_ASSERT(sizeof(DomainType)==0);
#endif
};

/// Floating-point interval variable.
template<typename DomainType>
class FloatVar : public VarBase<FloatVarImp<DomainType> >
{
public:
  /// Variable implementation (helper typedef).
  typedef FloatVarImp<DomainType> VarImp;
  typedef FloatView<DomainType>   View;
  /// Base class (helper typedef).
  typedef VarBase<VarImp> Base;
  // Helper typedefs:
  typedef typename VarImp::numeric_type       numeric_type;
  typedef typename VarImp::interval_type      interval_type;
  typedef typename VarImp::interval_type_cr   interval_type_cr;
  typedef typename VarImp::constant_type      constant_type;
  typedef typename VarImp::constant_type_cr   constant_type_cr;
  using Base::varimp;
private:
  /**
   * \brief Initialize variable with range domain
   *
   * The variable is created with a domain ranging from \a min
   * to \a max. No exceptions are thrown.
   */
  forceinline void
  _init(Space* home, interval_type_cr dt) {
    varimp = new (home) VarImp(home, dt);
  }
public:
  /// \name Constructors and initialization
  //@{
  /// Default constructor
  FloatVar(void) {}
  
  /// Initialize from float variable \a x
  FloatVar(const FloatVar& x)
    : Base(x) {}

  /// Initialize from Float view \a x
  FloatVar(const View& x)
    : Base(x.var()) {}

  /// Initialize from reflection variable \a x
  FloatVar(const Reflection::Var& x)
    : VarBase<VarImp>(x) {}

  /// Initialize variable with range domain
  FloatVar(Space* home, interval_type_cr dt) {
    _init(home, dt);
  }
  
  /// Initialize variable with range domain
  void init(Space* home, interval_type_cr dt) {
    _init(home, dt);
  }
  //@}
  
  forceinline constant_type_cr
  val(void) {
    return varimp->val();
  }
  
  forceinline VarImp*
  variable(void) const {
    return varimp;
  }
  
  /// \name Value access
  //@{
  /// Return minimum of domain
  forceinline numeric_type
  min(void) const {
    return varimp->min();
  }
  /// Return maximum of domain
  forceinline numeric_type
  max(void) const {
    return varimp->max();
  }
  /// Return actual domain
  forceinline interval_type_cr
  domain(void) const {
    return varimp->domain();
  }

  /*
   * Domain update by value
   */
  forceinline ModEvent
  lq(Space* home, numeric_type n) {
   return varimp->lq(home, n);
  }
  forceinline ModEvent
  lq(Space* home, constant_type_cr n) {
   return varimp->lq(home, n);
  }
  forceinline ModEvent
  gq(Space* home, numeric_type n) {
    return varimp->gq(home, n);
  }
  forceinline ModEvent
  gq(Space* home, constant_type_cr n) {
    return varimp->gq(home, n);
  }
  forceinline ModEvent
  eq(Space* home, constant_type_cr n) {
   return varimp->eq(home, n);
  }
  /// Restrict domain to the upper half.
  forceinline ModEvent
  split_upper(Space* home) {
    return varimp->split_upper(home);
  }
  /// Restrict domain to the lower half.
  forceinline ModEvent
  split_lower(Space* home) {
    return varimp->split_lower(home);
  }
  
  /// Return size (cardinality) of domain
  forceinline numeric_type
  size(void) const {
    return varimp->size();
  }
  /// Return width of domain (distance between maximum and minimum)
  forceinline numeric_type
  width(void) const {
    return varimp->width();
  }    
  //@}
  
  /// \name Domain tests
  //@{
  /// Test whether domain is a range
  forceinline bool
  range(void) const {
    return varimp->range();
  }
  
  /// Test whether view is assigned
  forceinline bool
  assigned(void) const {
    return varimp->assigned();
  }
  
  /// Test whether \a n is contained in domain
  forceinline bool
  in(constant_type_cr n) const {
    return varimp->in(n);
  }
  //@}
  
  /// \name Cloning
  //@{
  /// Update this variable to be a clone of variable \a x
  forceinline void
  update(Space* home, bool share, FloatVar& x) {
    varimp = x.varimp->copy(home, share);
  }
  //@}
};

template<typename FloatVarI>
struct FloatVarArray : public Gecode::VarArray<FloatVarI> {
  typedef typename FloatVarI::interval_type_cr  interval_type_cr;
  using Gecode::VarArray<FloatVarI>::x;
  FloatVarArray()
    : Gecode::VarArray<FloatVarI>()
  { }

  FloatVarArray(Space* home, int m )
    : Gecode::VarArray<FloatVarI>(home, m)
  { }

  FloatVarArray(const FloatVarArray& a)
    : Gecode::VarArray<FloatVarI>(a)
  { }
  FloatVarArray(Space* home, int n, interval_type_cr init_dom)
    : Gecode::VarArray<FloatVarI>(home, n)
  {
    for(int i=0; i<n; i++) {
      FloatVarI& _x = x[i];
      _x.init(home, init_dom);
    }
  }
};

} // namespace Float

} // namespace Gecode

#endif // !FLOAT__FLOAT_VAR_HH

