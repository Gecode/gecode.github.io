FloatVar for Gecode (updated 2008/08/27)
========================================

This is a release of float variables support for Gecode, compatible
with Gecode 2.1.1.

To use it, download Gecode 2.1.1 source package, apply the patch
./patch/float.patch to add support for float variables to Gecode and build
Gecode.

The current implementation supports Boost.Interval as the low-level interval
arithmetics support library. Download Boost 1.35 or later (see
http://www.boost.org). There is no need to build any of the Boost libraries
for the purposes of this library (we're only using Boost's enable_if, numeric,
lexical_cast and static_assert).

To build the example in ./example, you have to point the compiler to several
include directories: Boost, Gecode and FloatVar. You can use the provided
CMake script to generate Makefile/project files for your development
environment (see http://www.cmake.org).

