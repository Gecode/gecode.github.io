/* -*- mode: C++; c-basic-offset: 2; indent-tabs-mode: nil -*- */
/*
 *  Main authors:
 *     Filip Konvicka <filip.konvicka@logis.cz>
 *
 *  Copyright:
 *     LOGIS, s.r.o., 2008
 *
 *  Last modified:
 *     $Date$ by $Author$
 *     $Revision$
 *
 *  Permission is hereby granted, free of charge, to any person obtaining
 *  a copy of this software and associated documentation files (the
 *  "Software"), to deal in the Software without restriction, including
 *  without limitation the rights to use, copy, modify, merge, publish,
 *  distribute, sublicense, and/or sell copies of the Software, and to
 *  permit persons to whom the Software is furnished to do so, subject to
 *  the following conditions:
 *
 *  The above copyright notice and this permission notice shall be
 *  included in all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 *  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 *  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 *  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */

#if !defined(GECODE__FLOAT_HH)
#define GECODE__FLOAT_HH

#include <gecode/kernel.hh>
#include <gecode/int.hh>

#include <string>

#include <boost/static_assert.hpp>
#include <boost/lexical_cast.hpp>

namespace Gecode { namespace Float {

#pragma region // Forward declarations
  // Generic:
template<typename DomainType> class  FloatVar;
template<typename DomainType> class  FloatView;
template<typename FloatVarI>  struct FloatVarArray;
template<typename FV, typename Fct, typename ValFct> class Split;
  // Specialized:
template<typename DomainType> struct FloatVarImp;
template<typename DomainType> class  FloatDelta;
template<typename DomainType> class  ScaleView;
template<typename DomainType> struct FloatPropagatorBase;
template<typename DomainType, typename FV1, typename FV2> class  Relational;
template<typename DomainType, typename FV1, typename FV2, typename BV> class  ReifiedRelational;
template<typename DomainType, typename FV1, typename FV2, typename FV3> class  Arithmetic;
template<typename DomainType, typename FV> class  Linear;
template<typename DomainType, typename FV, typename BV> class  ReifiedLinear;
#pragma endregion

#pragma region // Helper templates for passing variables/views
namespace __Utils {
// Converts FloatVar to FloatView, or retains original float view type.
template<typename ViewType> struct FloatVarToView {
  typedef ViewType        type;
  typedef ViewType const& arg_type;
};

template<typename T> struct FloatVarToView<FloatVar<T> > {
  typedef FloatView<T>  type;
  typedef type          arg_type;
};

// Converts VarArray<FloatVar> to ViewArray<FloatView>, or retains original var array type.
template<typename ViewArrayType> struct FloatVarsToViews;

template<typename ViewType> struct FloatVarsToViews<ViewArray<ViewType> > {
  typedef typename ViewType::interval_type  interval_type;
  typedef ViewType                          view_type;
  typedef ViewArray<ViewType> const&        init_type;
  typedef ViewArray<ViewType>               type;
};

template<typename T> struct FloatVarsToViews<VarArgArray<FloatVar<T> > > {
  typedef T                                 interval_type;
  typedef FloatView<T>                      view_type;
  typedef VarArgArray<FloatVar<T> > const&  init_type;
  typedef ViewArray<view_type>              type;
};

template<typename T> struct FloatVarsToViews<VarArray<FloatVar<T> > > {
  typedef T                         interval_type;
  typedef FloatView<T>              view_type;
  typedef VarArgArray<FloatVar<T> > init_type;
  typedef ViewArray<view_type>      type;
};

template<typename T> struct FloatVarsToViews<FloatVarArray<FloatVar<T> > > {
  typedef T                         interval_type;
  typedef FloatView<T>              view_type;
  typedef VarArgArray<FloatVar<T> > init_type;
  typedef ViewArray<view_type>      type;
};

// Converts BoolVar to BoolView, and retains original view type otherwise.
template<typename ViewType> struct BoolVarToView {
  typedef ViewType        type;
  typedef ViewType const& arg_type;
};

template<> struct BoolVarToView<BoolVar> {
  typedef Int::BoolView type;
  typedef type          arg_type;
};

} // namespace __Utils
#pragma endregion

/// Serialization for domain type. Specialize this template to enable serialization for your domain type.
template<typename DomainType>
struct SerializationTraits {
  /// Retrieves domain textual representation.
  static std::string to_string(DomainType const& dom) {
    return "["+number_to_string(dom.lower())+"; "+number_to_string(dom.upper())+"]";
  }
  /// Domain serialization.
  static Reflection::Arg* serialize(DomainType const& dom) {
    return Reflection::Arg::newString(boost::lexical_cast<std::string>(dom));
  }
  /// Deserialization.
  static DomainType deserialize(Reflection::Arg* arg) {
    return boost::lexical_cast<DomainType>(arg->toString());
  }
  /// Retrieves number textual representation.
  template<typename N> static std::string number_to_string(N const& number) {
    return boost::lexical_cast<N>(number);
  }
  /// Number serialization.
  template<typename N> static Reflection::Arg* serialize_number(N const& number) {
    return Reflection::Arg::newString(boost::lexical_cast<std::string>(number));
  }
  /// Number deserialization.
  template<typename N> static void deserialize_number(Reflection::Arg* arg, N& number) {
    number = boost::lexical_cast<N>(arg->toString());
  }
};

} // namespace Float

} // namespace Gecode

#pragma region // Generic templates definitions/declarations
// Variable (definition), variable implementation & delta (empty generic declaration)
#include "float/float_var.hh"
// FloatView (definition), ScaleView (empty generic declaration)
#include "float/float_view.hh"
// Operator definitions, propagators (relational, arithmetic, linear...) - empty generic declarations
#include "float/float_prop.hh"
// Branchings
#include "float/float_branching.hh"
#pragma endregion

/// Enables serialization of FloatVar for the given domain type.
#define GECODE_FLOAT_ENABLE_SERIALIZATION(DomainType)   \
                                                        \
namespace Gecode { namespace Float { namespace {        \
  Reflection::VarImpRegistrar<FloatVarImp<DomainType> > \
    registerFloatVarImp;                                \
} } }

/// Explicitly instantiates all FloatVar classes for the given domain type.
#define GECODE_FLOAT_INSTANTIATE(DomainType)  \
                                              \
namespace Gecode { namespace Float {          \
  template class FloatVar<DomainType>;        \
  template class FloatView<DomainType>;       \
  template class FloatDelta<DomainType>;      \
  template struct FloatVarImp<DomainType>;    \
  template class ScaleView<DomainType>;       \
} }

#pragma region // FloatVar<Boost.Interval<T> >

// Boost.Interval implementation

namespace Gecode { namespace Float {

template<typename NumericType>
struct SerializationTraits<boost::numeric::interval<NumericType> > {
  typedef boost::numeric::interval<NumericType> DomainType;
  /// Retrieves domain textual representation.
  static std::string to_string(DomainType const& dom) {
    return "["+number_to_string(dom.lower())+"; "+number_to_string(dom.upper())+"]";
  }
  /// Domain serialization.
  static Reflection::Arg* serialize(DomainType const& dom) {
    return Reflection::Arg::newPair(
      serialize_number(dom.lower()),
      serialize_number(dom.upper()));
  }
  /// Domain deserialization.
  static DomainType deserialize(Reflection::Arg* arg) {
    NumericType lower, upper;
    deserialize_number(arg->first(), lower);
    deserialize_number(arg->second(), upper);
    return DomainType(lower, upper, true); // true: low-level interval construction
  }

  /// Retrieves number textual representation.
  static std::string number_to_string(NumericType const& number) {
    return boost::lexical_cast<std::string>(number);
  }
  /// Number serialization.
  static Reflection::Arg* serialize_number(NumericType const& number) {
    return Reflection::Arg::newString(boost::lexical_cast<std::string>(number).c_str());
  }
  /// Number deserialization.
  static void deserialize_number(Reflection::Arg* arg, NumericType& number) {
    number=boost::lexical_cast<NumericType>(arg->toString());
  }
};

} }

#include "float/bi/delta.icc"
#include "float/bi/varimp.icc"
#include "float/bi/view.icc"
#include "float/bi/prop.hh"

/// Enables serialization of FloatVar/Boost.Interval for the given numeric type.
/// This can be used in a cpp file to enable serialization for FloatVars of the given type.
#define GECODE_FLOAT_BI_ENABLE_SERIALIZATION(NumericType) \
  GECODE_FLOAT_ENABLE_SERIALIZATION(boost::numeric::interval<NumericType>)

/// Instantiates all FloatVar/Boost.Interval classes for the given numeric type.
/// This can be used in a cpp file to explicitly instantiate the templates.
#define GECODE_FLOAT_BI_INSTANTIATE(NumericType)  \
  GECODE_FLOAT_INSTANTIATE(boost::numeric::interval<NumericType>)

#pragma endregion

#endif // !GECODE__FLOAT_HH

