/* -*- mode: C++; c-basic-offset: 2; indent-tabs-mode: nil -*- */
/*
 *  Main authors:
 *     Filip Konvicka <filip.konvicka@logis.cz>
 *
 *  Copyright:
 *     LOGIS, s.r.o., 2008
 *
 *  Last modified:
 *     $Date$ by $Author$
 *     $Revision$
 *
 *  Permission is hereby granted, free of charge, to any person obtaining
 *  a copy of this software and associated documentation files (the
 *  "Software"), to deal in the Software without restriction, including
 *  without limitation the rights to use, copy, modify, merge, publish,
 *  distribute, sublicense, and/or sell copies of the Software, and to
 *  permit persons to whom the Software is furnished to do so, subject to
 *  the following conditions:
 *
 *  The above copyright notice and this permission notice shall be
 *  included in all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 *  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 *  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 *  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */

#ifndef FLOAT__FLOAT_PROP_HH
#define FLOAT__FLOAT_PROP_HH

#include "float_var.hh"
#include "float_view.hh"

namespace Gecode { namespace Float {

/// Relational operators available for floats.
typedef enum {
  FLOAT_REL_LQ,   ///< Less than or equal
  FLOAT_REL_GQ,   ///< Greater than or equal
  FLOAT_REL_EQ,   ///< Equal to
  FLOAT_REL_NE,   ///< Not equal to (value consistency only)
} Float_Rel;

/// Arithmetic operators available for floats.
typedef enum {
  FLOAT_F_MIN,  ///< Minimum of a set
  FLOAT_F_MAX,  ///< Maximum of a set
  FLOAT_F_ADD,  ///< Addition
  FLOAT_F_SUB,  ///< Subtraction
  FLOAT_F_MUL,  ///< Multiplication
  FLOAT_F_DIV   ///< Division
} Float_F;

/// General FloatVar propagator.
template<typename DomainType>
struct FloatPropagatorBase {
  // Specialize this for DomainType.
#if defined(BOOST_STATIC_ASSERT)
  BOOST_STATIC_ASSERT(sizeof(DomainType)==0);
#endif
};

/// Binary relation propagator
template<typename DomainType, typename FV1, typename FV2>
class Relational : public FloatPropagatorBase<DomainType>, public Propagator {
  // Specialize this for DomainType.
#if defined(BOOST_STATIC_ASSERT)
  BOOST_STATIC_ASSERT(sizeof(DomainType)==0);
#endif
};

/// Reified arithmetic binary relation propagator
template<typename DomainType, typename FV1, typename FV2, typename BV>
class ReifiedRelational : public FloatPropagatorBase<DomainType>, public Propagator {
  // Specialize this for DomainType.
#if defined(BOOST_STATIC_ASSERT)
  BOOST_STATIC_ASSERT(sizeof(DomainType)==0);
#endif
};

/// Ternary arithmetic propagator
template<typename DomainType, typename FV1, typename FV2, typename FV3>
class Arithmetic : public FloatPropagatorBase<DomainType>, public Propagator {
  // Specialize this for DomainType.
#if defined(BOOST_STATIC_ASSERT)
  BOOST_STATIC_ASSERT(sizeof(DomainType)==0);
#endif
};

/// Linear arithmetic propagator
template<typename DomainType, typename FV>
class Linear : public FloatPropagatorBase<DomainType>, public Propagator {
  // Specialize this for IntervalType.
#if defined(BOOST_STATIC_ASSERT)
  BOOST_STATIC_ASSERT(sizeof(DomainType)==0);
#endif
};

/// Reified linear arithmetic propagator.
template<typename DomainType, typename FV, typename BV>
class ReifiedLinear : public FloatPropagatorBase<DomainType>, public Propagator {
  // Specialize this for DomainType.
#if defined(BOOST_STATIC_ASSERT)
  BOOST_STATIC_ASSERT(sizeof(DomainType)==0);
#endif
};

} // namespace Float

} // namespace Gecode

#endif // !FLOAT__FLOAT_PROP_HH

