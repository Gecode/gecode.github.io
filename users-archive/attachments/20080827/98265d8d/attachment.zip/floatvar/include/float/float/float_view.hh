/* -*- mode: C++; c-basic-offset: 2; indent-tabs-mode: nil -*- */
/*
 *  Main authors:
 *     Filip Konvicka <filip.konvicka@logis.cz>
 *     Lubomir Moric <lubomir.moric@logis.cz>
 *
 *  Copyright:
 *     LOGIS, s.r.o., 2008
 *
 *  Last modified:
 *     $Date$ by $Author$
 *     $Revision$
 *
 *  Permission is hereby granted, free of charge, to any person obtaining
 *  a copy of this software and associated documentation files (the
 *  "Software"), to deal in the Software without restriction, including
 *  without limitation the rights to use, copy, modify, merge, publish,
 *  distribute, sublicense, and/or sell copies of the Software, and to
 *  permit persons to whom the Software is furnished to do so, subject to
 *  the following conditions:
 *
 *  The above copyright notice and this permission notice shall be
 *  included in all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 *  MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 *  LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 *  OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 *  WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */

#if !defined(FLOAT__FLOAT_VIEW_HH)
#define FLOAT__FLOAT_VIEW_HH

#include "float_var.hh"

namespace Gecode {
  
/**
 * \brief Defines traits for views.
 *
 * This specializes ViewVarImpTraits templates for FloatView.
 */
template<typename DomainType>
class ViewVarImpTraits<Float::FloatView<DomainType> > {
public:
  typedef Float::FloatVarImp<DomainType> VarImp;
};
/**
 * \brief Defines traits for variables and variable implementations.
 *
 * This specializes VarViewTraits templates for FloatVar.
 */
template<typename DomainType>
class VarViewTraits<Float::FloatVar<DomainType> > {
public:
  typedef Float::FloatView<DomainType> View;
};

namespace Float {

/// Exception for incorrect input.
struct OutOfLimits : public Exception {
  OutOfLimits(const char* l) : Exception(l, "Number out of limits") {}
};

/// Float variable view (generic).
template<typename DomainType>
class FloatView : public VarViewBase<FloatVarImp<DomainType> >
{
public:
  /// Variable implementation.
  typedef FloatVarImp<DomainType> VarImp;
  /// Base class.
  typedef VarViewBase<VarImp> Base;

  // Helper typedefs.
  typedef FloatVar<DomainType>                Var;
  typedef typename VarImp::numeric_type       numeric_type;
  typedef typename VarImp::interval_type      interval_type;
  typedef typename VarImp::interval_type_cr   interval_type_cr;
  typedef typename VarImp::constant_type      constant_type;
  typedef typename VarImp::constant_type_cr   constant_type_cr;
protected:
  using VarViewBase<VarImp>::varimp;

public:
  /*
   * Constructors and initialization
   */
  forceinline
  FloatView(void) {}

  forceinline
  FloatView(Var const& x)
    : Base(x.var()) {}

  forceinline
  FloatView(Var* x)
    : Base(x->var()) {}

  forceinline
  FloatView(Space* /*home*/, const Reflection::VarMap& vars,
            Reflection::Arg* arg)
    : Base(Var(vars.var(arg->toVar())).var())
  {}

  /*
   * Value access
   */
  forceinline numeric_type
  min(void) const {
    return varimp->min();
  }
  forceinline numeric_type
  max(void) const {
    return varimp->max();
  }
  forceinline interval_type_cr
  domain(void) const {
    return varimp->domain();
  }
  forceinline constant_type_cr
  val(void) const {
    return varimp->val();
  }

  forceinline numeric_type
  size(void) const {
    return varimp->size();
  }
  forceinline numeric_type
  width(void) const {
    return varimp->width();
  }
  forceinline constant_type
  med(void) const {
    return varimp->med();
  }
  forceinline numeric_type
  median(void) const {
    return varimp->median();
  }

  /*
   * Domain tests
   */
  forceinline bool
  range(void) const {
    return varimp->range();
  }
  forceinline bool
  assigned(void) const {
    return varimp->assigned();
  }
  forceinline bool
  in(constant_type_cr n) const {
    return varimp->in(n);
  }

  /*
   * Domain update by value
   */
  forceinline ModEvent
  lq(Space* home, numeric_type n) {
   return varimp->lq(home, n);
  }
  forceinline ModEvent
  lq(Space* home, constant_type_cr n) {
   return varimp->lq(home, n);
  }
  forceinline ModEvent
  gq(Space* home, numeric_type n) {
    return varimp->gq(home, n);
  }
  forceinline ModEvent
  gq(Space* home, constant_type_cr n) {
    return varimp->gq(home, n);
  }
  forceinline ModEvent
  eq(Space* home, constant_type_cr n) {
   return varimp->eq(home, n);
  }
  /// Restrict domain to the upper half.
  forceinline ModEvent
  split_upper(Space* home) {
    return varimp->split_upper(home);
  }
  /// Restrict domain to the lower half.
  forceinline ModEvent
  split_lower(Space* home) {
    return varimp->split_lower(home);
  }

  forceinline interval_type
  getMinConstraint(numeric_type target_width) const {
    return varimp->getMinConstraint(target_width);
  }
  forceinline interval_type
  getMaxConstraint(numeric_type target_width) const {
    return varimp->getMaxConstraint(target_width);
  }

  /*
   * Delta information for advisors
   */
  static forceinline ModEvent
  modevent(const Delta* d) {
    return VarImp::modevent(d);
  }
  forceinline numeric_type
  min(const Delta* d) const {
    return varimp->min(d);
  }
  forceinline numeric_type
  max(const Delta* d) const {
    return varimp->max(d);
  }
  forceinline bool
  any(const Delta* d) const {
    return varimp->any(d);
  }

  static forceinline ModEventDelta
  med(ModEvent me) {
    return Base::med(me);
  }

  /*
   * Cloning
   */
  forceinline void
  update(Space* home, bool share, FloatView& x) {
    varimp = x.varimp->copy(home, share);
  }

  /*
   * Serialization
   */
  forceinline Reflection::Arg*
  spec(const Space* home, Reflection::VarMap& m) const {
    return varimp->spec(home, m);
  }
  inline static Support::Symbol type(void) {
    return Support::Symbol("Gecode::Float::FloatView");
  }
};

/**
 * \brief Scale float view
 *
 * A scale view \f$s\f$ for a float view \f$x\f$ and
 * a nonzero number \f$c\f$ provides operations such that \f$s\f$
 * behaves as \f$c\cdot x\f$.
 *
 * Note that scale float views do not provide operations
 * for updating domains by range iterators.
 */
template<typename DomainType>
class ScaleView : public DerivedViewBase<FloatView<DomainType> > {
  // Please specialize this for DomainType.
#if defined(BOOST_STATIC_ASSERT)
  BOOST_STATIC_ASSERT(sizeof(DomainType)==0);
#endif
};

} // namespace Float

} // namespace Gecode
 
#endif // !FLOAT__FLOAT_VIEW_HH

