/*
 *  Gecode geometrical packing propagator variant where boxes from the same
 *  partition are allowed to overlap.
 *
 *  Roberto Castaneda Lozano <rcas@sics.se>
 *  http://www.sics.se/~rcas/
 *
 */

#include "nocrossoverlappropagator.hpp"

namespace Gecode { namespace Int { namespace NoOverlap {

  template<class Dim, int n>
  forceinline void
  ClassBox<Dim,n>::bclass(int c0) {
    c = c0;
  }

template<class Dim, int n>
  forceinline bool
  ClassBox<Dim,n>::nooverlap(const ClassBox<Dim,n>& box) const {
    return (c == box.c) ? true : ManBox<Dim,n>::nooverlap(box);
  }

  template<class Dim, int n>
  forceinline bool
  ClassBox<Dim,n>::overlap(const ClassBox<Dim,n>& box) const {
    return (c == box.c) ? false : ManBox<Dim,n>::overlap(box);
  }

  template<class Dim, int n>
  forceinline ExecStatus
  ClassBox<Dim,n>::nooverlap(Space& home, ClassBox<Dim,n>& box) {
    assert (c != box.c);
    return ManBox<Dim,n>::nooverlap(home, box);
  }

  template<class Dim, int n>
  forceinline void
  ClassBox<Dim,n>::update(Space& home, bool share, ClassBox<Dim,n>& b) {
    ManBox<Dim,n>::update(home, share, b);
    c = b.c;
  }


}}}

void
nocrossoverlap(Home home,
               const IntVarArgs& x0, const IntVarArgs& w,
               const IntVarArgs& x1, const IntVarArgs& y0,
               const IntVarArgs& h, const IntVarArgs& y1,
               const IntArgs& c, IntConLevel) {
  using namespace Int;
  using namespace NoOverlap;
  if ((x0.size() != w.size())  || (x0.size() != x1.size()) ||
      (x0.size() != y0.size()) || (x0.size() != h.size()) ||
      (x0.size() != y1.size()) || (x0.size() != c.size()))
    throw ArgumentSizeMismatch("Int::nooverlap");
  if (x0.same(home) || w.same(home) || x1.same(home) ||
      y0.same(home) || h.same(home) || y1.same(home))
    throw ArgumentSame("Int::nooverlap");
  if (home.failed()) return;

  // TODO: Gecode's posting function does not seem to need this..
  if (x0.size() == 0) return;

  for (int i=x0.size(); i--; ) {
    GECODE_ME_FAIL(IntView(w[i]).gq(home,0));
    GECODE_ME_FAIL(IntView(h[i]).gq(home,0));
  }

  bool equivalent = false;
  std::set<int> classes;
  for (int i=c.size(); i--; ) {
    if (classes.count(c[i])) {
      equivalent = true;
      break;
    } else classes.insert(c[i]);
  }

  if (equivalent) {
    ClassBox<FlexDim,2>* b
      = static_cast<Space&>(home).alloc<ClassBox<FlexDim,2> >(x0.size());
    for (int i=x0.size(); i--; ) {
      b[i][0] = FlexDim(x0[i],w[i],x1[i]);
      b[i][1] = FlexDim(y0[i],h[i],y1[i]);
      b[i].bclass(c[i]);
    }
    GECODE_ES_FAIL((
      NoOverlap::ManProp<ClassBox<FlexDim,2> >::post(home,b,x0.size())));
  } else {  // If each box belongs to a different class, propagate with ManBox
    ManBox<FlexDim,2>* b
      = static_cast<Space&>(home).alloc<ManBox<FlexDim,2> >(x0.size());
    for (int i=x0.size(); i--; ) {
      b[i][0] = FlexDim(x0[i],w[i],x1[i]);
      b[i][1] = FlexDim(y0[i],h[i],y1[i]);
    }
    GECODE_ES_FAIL((
      NoOverlap::ManProp<ManBox<FlexDim,2> >::post(home,b,x0.size())));
  }

}
