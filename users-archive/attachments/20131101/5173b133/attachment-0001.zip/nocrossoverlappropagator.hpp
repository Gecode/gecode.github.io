/*
 *  Gecode geometrical packing propagator variant where boxes from the same
 *  partition are allowed to overlap.
 *
 *  Roberto Castaneda Lozano <rcas@sics.se>
 *  http://www.sics.se/~rcas/
 *
 */

#ifndef __NOCROSSOVERLAP_PROPAGATOR__
#define __NOCROSSOVERLAP_PROPAGATOR__

#include <set>
#include <gecode/int.hh>
#include <gecode/int/no-overlap.hh>

using namespace Gecode;

namespace Gecode { namespace Int { namespace NoOverlap {

  // Mandatory box belonging to a class
  template<class Dim, int n>
  class ClassBox : public ManBox<Dim,n> {
  protected:
    // Class to which the box belongs
    int c;
  public:
    /// Set class to c0
    void bclass(int c0);

    /// Check whether this box does not any longer overlap with b
    bool nooverlap(const ClassBox<Dim,n>& b) const;

    /// Check whether this box overlaps with b
    bool overlap(const ClassBox<Dim,n>& b) const;

    /// Propagate that this box does not overlap with b
    ExecStatus nooverlap(Space& home, ClassBox<Dim,n>& b);

    /// Update box during cloning
    void update(Space& home, bool share, ClassBox<Dim,n>& r);

  };

}}}

void
nocrossoverlap(Home home,
               const IntVarArgs& x0, const IntVarArgs& w, const IntVarArgs& x1,
               const IntVarArgs& y0, const IntVarArgs& h, const IntVarArgs& y1,
               const IntArgs& c, IntConLevel icl=ICL_DEF);

#endif
